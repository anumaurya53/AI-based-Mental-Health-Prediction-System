import React, { useState } from "react";

function Signup({ goLogin }) {

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  const handleSignup = async () => {
    try {
      const res = await fetch("http://127.0.0.1:9696/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();

      if (data.error) {
        setMsg("❌ " + data.error);
      } else {
        setMsg("✅ Signup successful");
      }

    } catch (err) {
      setMsg("❌ Backend error");
    }
  };

  return (
    <div style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      background: "linear-gradient(to right, #667eea, #764ba2)"
    }}>
      <div style={{
        background: "white",
        padding: "30px",
        borderRadius: "12px",
        width: "300px",
        textAlign: "center"
      }}>
        <h2>📝 Signup</h2>

        <input
          placeholder="Username"
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleSignup}>Signup</button>

        <p>{msg}</p>

        <p
          style={{ cursor: "pointer", color: "blue" }}
          onClick={goLogin}
        >
          Already have account? Login
        </p>
      </div>
    </div>
  );
}

export default Signup;