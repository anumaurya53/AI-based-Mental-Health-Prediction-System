import React from "react";

function About() {
  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.heading}>📘 About This Project</h2>

        <p style={styles.text}>
          This project is a <b>Mental Health Prediction System</b> that analyzes
          user input to determine their mental condition using machine learning.
        </p>

        <p style={styles.text}>
          It combines a <b>React frontend</b> with a <b>Flask backend</b>, where
          the trained ML model processes the data and generates predictions.
        </p>

        <p style={styles.text}>
          The system also provides <b>personalized recommendations</b> to help
          users improve their mental well-being.
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "80vh",
    background: "linear-gradient(to right, #667eea, #764ba2)"
  },
  card: {
    background: "white",
    padding: "30px",
    borderRadius: "12px",
    width: "500px",
    boxShadow: "0 10px 25px rgba(0,0,0,0.2)"
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px"
  },
  text: {
    marginBottom: "15px",
    lineHeight: "1.6"
  }
};

export default About;